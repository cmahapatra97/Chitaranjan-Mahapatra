#include <stdio.h>
#include "hocdec.h"
#define IMPORT extern __declspec(dllimport)
IMPORT int nrnmpi_myid, nrn_nobanner_;

extern void _BKCAm_reg();
extern void _CAD_reg();
extern void _CaL_reg();
extern void _CaT_reg();
extern void _Exp2Syn_reg();
extern void _IH_reg();
extern void _IKCA_reg();
extern void _KATP_reg();
extern void _KCNQ_reg();
extern void _KV2_reg();
extern void _SKCA_reg();

modl_reg(){
	//nrn_mswindll_stdio(stdin, stdout, stderr);
    if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," BKCAm.mod");
fprintf(stderr," CAD.mod");
fprintf(stderr," CaL.mod");
fprintf(stderr," CaT.mod");
fprintf(stderr," Exp2Syn.mod");
fprintf(stderr," IH.mod");
fprintf(stderr," IKCA.mod");
fprintf(stderr," KATP.mod");
fprintf(stderr," KCNQ.mod");
fprintf(stderr," KV2.mod");
fprintf(stderr," SKCA.mod");
fprintf(stderr, "\n");
    }
_BKCAm_reg();
_CAD_reg();
_CaL_reg();
_CaT_reg();
_Exp2Syn_reg();
_IH_reg();
_IKCA_reg();
_KATP_reg();
_KCNQ_reg();
_KV2_reg();
_SKCA_reg();
}
